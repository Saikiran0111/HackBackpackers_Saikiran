#We can take input and implement in ADF using isNULL and isUpsert()

def isinsert(n):
    if isNull(n):
        if isUpsert(1):
            val=n
    return n1
n=input()
print(isinsert(n))