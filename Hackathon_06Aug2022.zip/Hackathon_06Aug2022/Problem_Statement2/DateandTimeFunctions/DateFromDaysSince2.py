#We can implement this in ADf using addDays() function
def adddays(date,days):
    s=addDays(toDate(date), days)
return s

Date=input()
days=int(input())
print(addDays(toDate('2016-08-08'), 1))