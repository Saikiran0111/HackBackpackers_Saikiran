#We can implement this in ADf using minute() function

def minute_ADF(Timestamp):
     m=minute(toTimestamp(Timestamp))
     return m
n=input()
ans=minute_ADF(n)
print(ans)