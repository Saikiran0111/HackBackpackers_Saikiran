
#We will get Timestamp in ADF using currentTimestamp() function.
def get_curr_date:
    curr_dt=currentTimestamp()
    return curr_dt