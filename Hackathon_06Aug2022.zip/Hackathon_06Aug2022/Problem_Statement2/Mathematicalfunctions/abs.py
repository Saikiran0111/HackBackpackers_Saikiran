#We can take 2 numbers as input and implement in ADF using abs()
def abs_adf(n1,n2):
    n=n1-n2
    return abs(n)

n1=int(input())
n2=int(input())
print(abs_adf(n1,n2))
