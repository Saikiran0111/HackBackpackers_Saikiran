#We can use typematch() and implement in ADF by giving Double

def Double_ADF(n):
    r=typematch('Double',n)
    return r

n=int(input())
print(Double_ADF(n))