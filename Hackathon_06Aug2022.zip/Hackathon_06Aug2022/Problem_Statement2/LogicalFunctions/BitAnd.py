#We can convert Decimal to Hexadecimal and implement in ADF
def bitwise_and(n1,n2):
    r1=hex(n1)
    r2=hex(n2)
    res=biwiseAnd(r1,r2)
    return res

n1=input()
n2=input()

