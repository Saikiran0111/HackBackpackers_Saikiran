#We can convert Binary to Decimal and implement in ADF using todecimal()
def bitwise_and(binary):
    r=int(n,2)
    res=todecimal(r)
    return res

binary=input()