def str(str,n):
    s=str*n
    return s