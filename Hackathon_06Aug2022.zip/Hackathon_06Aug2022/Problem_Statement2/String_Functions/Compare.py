
def compare_adf(s1,s2):
    if s=='L':
        if(len(s1)>len(s2)):
            return 1
        else:
            return -1
    elif:
        if s=='R':
            if (len(s1) < len(s2)):
                return 1
            else:
                return -1
