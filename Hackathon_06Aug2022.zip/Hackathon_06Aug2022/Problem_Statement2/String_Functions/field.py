
def field_adf(str,delimeter,n):
    adf_s=split(n,delimeter)
    result=substring(adf_s,n)
    return result
